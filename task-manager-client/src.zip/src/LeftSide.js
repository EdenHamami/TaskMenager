import React from 'react'

function LeftSide() {
  return (
    <div className='left-side'>
        <header className="-header">
</header>

    </div>
  )
}

export default LeftSide